<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/28/2018
 * Time: 1:20 AM
 */

class Supplier_m extends MY_Model
{
    protected $_table_name  = 'supplier';
    protected $_timestamps  = TRUE;
}