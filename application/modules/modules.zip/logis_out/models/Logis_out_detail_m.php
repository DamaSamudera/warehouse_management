<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/29/2018
 * Time: 2:44 AM
 */

class Logis_out_detail_m extends MY_Model
{
    protected $_table_name = "shipping_detail";
}