<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/3/2018
 * Time: 7:41 PM
 */

class M_note extends MY_Model
{
    public $_table_name = 'note';
    protected $_timestamps = TRUE;
}