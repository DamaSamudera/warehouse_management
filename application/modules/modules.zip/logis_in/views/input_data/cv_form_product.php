<div class="row">
    <div class="col-md-8">

    </div>
    <div class="col-md-4">
        <div class="pull-right">
            <div class="col-xs-12">
                <div class="btn-group m-b-5 btn-lg">
                    <a href="<?= base_url('logis_in/product_action_form'); ?>" class="btn btn-success">Tambah Barang</a>
                    <button data-toggle="tooltip" type="button" data-status="stock order" class="btn btn-success process" type="submit"
                            data-original-title="Purchase Order"><i
                            class="fa fa-cart-plus"></i></button>
                    <button data-toggle="tooltip" type="button" class="btn btn-danger" onclick="window.location.reload()"
                            data-original-title="Reset"><i class="fa fa-trash-o"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>