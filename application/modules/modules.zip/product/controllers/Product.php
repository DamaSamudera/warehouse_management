<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/28/2018
 * Time: 7:40 PM
 */

class Product extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
    }

    public function index(){
        #======================== TEMPLATE ==========================#
        $this->data['view_content'] = 'list_product/tampilan';
        $this->data['script_content'] = 'list_product/script';

        $this->data['css_templates'] = $this->tampilan->datatable()['css'];
        $this->data['js_templates']  = $this->tampilan->datatable()['js'];
        $this->load->view('template/v_base_template', $this->data);
    }

}