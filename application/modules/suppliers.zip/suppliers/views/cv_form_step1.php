<div class="col-md-5 b-r b-dashed b-grey sm-b-b">
    <div class="padding-30 sm-padding-5 sm-m-t-15 m-t-50">
        <i class="fa fa-shopping-cart fa-2x hint-text"></i>
        <h2>Action Supplier</h2>
        <p>form untuk membantu mengelola informasi supplier yang memasok barang</p>
        <?php var_dump($supplier); ?>
    </div>
</div>
<div class="col-md-7">
    <div class="padding-30 sm-padding-5">
        <div class="form-group-attached">
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default disabled">
                        <label for="name">Supplier Code</label>
                        <input id='field-code' class='numeric form-control' name='code' type='text'
                               value="<?= $supplier->code ?>"
                               maxlength='45' readonly>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Supplier Name</label>
                        <input id='field-code' class='numeric form-control' name='name' type='text'
                               value="<?= $supplier->name ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">No NPWP</label>
                        <input id='field-code' class='numeric form-control' name='npwp' type='text'
                               value="<?= $supplier->npwp ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">No NPPKP</label>
                        <input id='field-code' class='numeric form-control' name='nppkp' type='text'
                               value="<?= $supplier->nppkp ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Phone Supplier</label>
                        <input id='field-code' class='numeric form-control' name='phone' type='text'
                               value="<?= $supplier->phone ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Contact Supplier</label>
                        <input id='field-code' class='numeric form-control' name='contact' type='text'
                               value="<?= $supplier->contact ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Fax Supplier</label>
                        <input id='field-code' class='numeric form-control' name='fax' type='text'
                               value="<?= $supplier->fax ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Handphone Supplier</label>
                        <input id='field-code' class='numeric form-control' name='handphone' type='text'
                               value="<?= $supplier->handphone ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Email Supplier</label>
                        <input id='field-code' class='numeric form-control' name='email' type='text'
                               value="<?= $supplier->email ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Note Supplier</label>
                        <input id='field-code' class='numeric form-control' name='description' type='text'
                               value="<?= $supplier->description ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Supplier Address</label>
                        <input id='field-code' class='numeric form-control' name='address' type='text'
                               value="<?= $supplier->address ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Credit Term Day</label>
                        <input id='field-code' class='numeric form-control' name='credit_term_day' type='text'
                               value="<?= $supplier->credit_term_day ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Bank</label>
                        <input id='field-code' class='numeric form-control' name='bank' type='text'
                               value="<?= $supplier->bank ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group form-group-default">
                        <label for="name">Credit Limit</label>
                        <input id='field-code' class='numeric form-control' name='credit_limit' type='text'
                               value="<?= $supplier->credit_limit ?>"
                               maxlength='45'>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group form-group-default">
                        <label for="name">Is Active</label>
                        <input type="checkbox" name="is_active" data-init-plugin="switchery" data-size="small"
                               data-color="primary"
                            <?= $supplier->is_active ?>/>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group form-group-default">
                        <label for="name">Is Internal</label>
                        <input type="checkbox" name="is_internal" data-init-plugin="switchery" data-size="small"
                               data-color="primary"
                            <?= $supplier->is_internal ?>/>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>