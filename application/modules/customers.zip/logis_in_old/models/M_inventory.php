<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/5/2018
 * Time: 8:18 PM
 */

class M_inventory extends MY_Model
{
    protected $_table_name  = 'n_inventory';
    protected $_timestamps  = TRUE;
}