<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/3/2018
 * Time: 8:29 PM
 */

class M_sales_draft extends MY_Model
{
    protected $_table_name  = 'n_sales';
}