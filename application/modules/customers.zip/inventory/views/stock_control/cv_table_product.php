
    <div class="card card-transparent">
        <div class="card-header ">
            <div class="pull-right">
                <div class="col-xs-12">
                    <input type="text" id="search-table-active" class="form-control pull-right" placeholder="Search">
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="card-block">
            <table class="table-inventory table table-hover" id="table_control">
                <thead>
                <tr>
                    <th style="width: 15%;">Product</th>
                    <th style="width: 17%;">Description</th>
                    <th style="width: 15%;">Supplier</th>
                    <th style="width: 13%;">Stock Awal</th>
                    <th style="width: 13%;">Stock Akhir</th>
                    <th style="width: 13%;">Stock In</th>
                    <th style="width: 13%;">Stock Out</th>
                    <!--<th style="width: 13%;">Retur Supp</th>-->
                    <!--<th style="width: 13%;">Retur Toko</th>-->
                    <th style="width: 18%;">Omzet</th>
                    <th style="width: 18%;">Asset</th>
                    <th style="width: 18%;">Profit</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
