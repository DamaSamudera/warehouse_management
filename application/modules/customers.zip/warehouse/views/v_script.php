<?php $this->load->view('cv_table_warehouse_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch('active');
        initTableWithSearch('inactive');

    });

</script>
