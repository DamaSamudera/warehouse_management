<?php $this->load->view('cv_table_store_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch('active');
        initTableWithSearch('inactive');

    });

</script>
