<!-- START Login Background Pic Wrapper-->
<div class="bg-pic">
    <!-- START Background Pic-->
    <img src="#" data-src="#" data-src-retina="#" alt="" class="lazy">
    <!-- END Background Pic-->
    <!-- START Background Caption-->
    <div id="content-help">
        <div class="bg-caption pull-bottom sm-pull-bottom text-white p-l-20 m-b-20">
            <h2 class="semi-bold text-white">
                <?= $this->lang->line('login_judul_slide'); ?>
            </h2>
            <p class="small">
                <?= $this->lang->line('login_content_slide'); ?>
            </p>
        </div>
    </div>
    <!-- END Background Caption-->
</div>
<!-- END Login Background Pic Wrapper-->