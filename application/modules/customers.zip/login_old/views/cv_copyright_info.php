<div class="pull-bottom sm-pull-bottom">
    <div class="m-b-30 p-r-80 sm-m-t-20 sm-p-r-15 sm-p-b-20 clearfix">
        <div class="col-sm-3 col-md-2 no-padding">
            <img alt="" class="m-t-5" data-src="assets/img/demo/pages_icon.png"
                 data-src-retina="assets/img/demo/pages_icon_2x.png"
                 src="assets/img/demo/pages_icon.png" width="40">
        </div>
        <div class="col-sm-9 no-padding m-t-10">
            <p>
                <small>
                    Copyright &copy; 2017. All rights reserved. Zone Of New Knowledge
                </small>
            </p>
        </div>
    </div>
</div>