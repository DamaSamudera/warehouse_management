<?php $this->load->view('sales_sc/cv_table_daily_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch();

    });

</script>
