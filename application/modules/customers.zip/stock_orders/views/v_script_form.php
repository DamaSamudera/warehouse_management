
<?php $this->load->view('cv_form_information_script'); ?>
<?php $this->load->view('cv_product_order_script'); ?>