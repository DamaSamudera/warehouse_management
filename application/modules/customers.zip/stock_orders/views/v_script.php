<?php $this->load->view('cv_table_stock_order_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch();

    });

</script>
