<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/11/2018
 * Time: 1:43 AM
 */

class M_stock_orders_detail extends MY_Model
{
    protected $_table_name = 'n_stock_order_detail';
}