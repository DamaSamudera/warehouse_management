<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/2/2018
 * Time: 12:34 AM
 */

class M_upload_product extends MY_Model
{
    protected $_table_name  = 'upload_product';
    protected $_order_by    = 'id';
}