<?php $this->load->view('cv_table_data_import_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch();

    });

</script>
