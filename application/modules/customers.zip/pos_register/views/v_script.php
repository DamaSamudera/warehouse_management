<?php $this->load->view('cv_table_pos_register_script'); ?>

<script type="text/javascript">

    $(document).ready(function(){
        //call
        initTableWithSearch();

    });

</script>
