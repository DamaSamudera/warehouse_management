<?php

$this->load->view('cv_form_product_script');
$this->load->view('cv_form_information_script');

?>