<div class="card card-transparent">
    <div class="card-block no-padding">
        <div id="card-advance" class="card card-default">
            <div class="card-header  ">
                <div class="card-title">Welcome</div>
            </div>
            <div class="card-block">
                <h3><span class="semi-bold">FNS</span> Application</h3>
                <p>Selamat datang di aplikasi FNS Application, pada aplikasi ini anda dapat mengelola informasi mengenai seluruh aktivitas kegiatan
                di perusahaan anda. Untuk informasi lebih lengkap anda dapat menggunakan menu bantuan atau anda dapat mengunjungi <a href="<?= base_url('help'); ?>">halaman ini</a></p>
            </div>
        </div>
    </div>
</div>
