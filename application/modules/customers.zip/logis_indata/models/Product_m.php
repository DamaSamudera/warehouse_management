<?php
/**
 * Created by PhpStorm.
 * User: Hidayat
 * Date: 2/11/2018
 * Time: 12:41 AM
 */

class Product_m extends MY_Model
{
    public $_table_name = 'product';

}