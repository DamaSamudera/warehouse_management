<div class="col-md-5 b-r b-dashed b-grey sm-b-b">
    <div class="padding-30 sm-padding-5 sm-m-t-15 m-t-50">
        <i class="fa fa-shopping-cart fa-2x hint-text"></i>
        <h2>Judul Form</h2>
        <p>Kegunaan</p>
    </div>
</div>
<div class="col-md-7">
    <div class="padding-30 sm-padding-5">
    </div>
</div>