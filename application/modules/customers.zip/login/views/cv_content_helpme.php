<?= date('Y-m-d H:i:s'); ?>
<br>
<?= $judul; ?>
<br>
<?= $masalah; ?>
