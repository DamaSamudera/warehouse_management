<?php
    $this->load->view('cv_cart_form_script');
    $this->load->view('cv_total_form_script');