<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/3/2018
 * Time: 10:23 AM
 */

class M_sales_detail extends MY_Model
{
    protected $_table_name  = 'sales_detail';
}