<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 3/2/2018
 * Time: 2:26 PM
 */

class M_customers extends MY_Model
{
    protected $_table_name  = 'customer';
    protected $_timestamps  = TRUE;
}